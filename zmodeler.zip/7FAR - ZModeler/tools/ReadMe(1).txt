Texture Toolkit is a tool for GTAV that allows you to edit textures in:
- texture dictionary files (*.ytd)
- drawable dictionary files (*.ydd)
- drawable files (*.ydr)
- fragment files (*.yft)
- particle files (*.ypt)

In the current version, you can only export to DDS files and import from DDS files.

Remember to backup your GTAV files before u use this tool!
Do NOT play GTA Online if you edited textures. I do not take responsibilities for possible bans.

Prerequisites:
 .NET Framework 4.5
 Visual C++ 2013 Runtime x86