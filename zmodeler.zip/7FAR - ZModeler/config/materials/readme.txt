----------------------------------------------------------------------------

    General purpose materials configuration scripts XML format:

----------------------------------------------------------------------------
<configset>
  <config title="Title" group="Branch1/Branch2" hint="Short description">

One or more config tags can be applied inside configset tag.



    <undo mode="mode1" />
    <undo mode="mode2" />

One or more undo tages can be applied per configuration.

mode: IMaterial - backup all (preferable when applies shader and samplers)
      Replace   - replace original material with the one created from config
      Basics    - backup basics (color, opacity, blend, options)
      Alpha     - backup alpha (opacity, affect map, alpha test)
      Textures  - obsole
      Sampler   - backup samplers. 
      Shader    - applies when shader is about to be assigned or changed
      Class     - applies when material class is about to change



    <alpha vertAffect="On" 
           mapAffect="Detail" 
           mapTexel="A"
           blendSrc="SrcAlpha"
           blendDest="InvSrcAlpha" 
           opacity="1.0"
           angularLevel="50"
           mapAffectLevel="1.0"
           clip="on"
           clipValue="128"/>
One alpha tag can be applied per configuration. All attributes are optional.

vertAffect : On/Off or true/false
mapAffect : Const, VertColor, Detail, Detail2, DirtMud, Detail3 or Decal, Bump,
            Normal, Spec, Env, Shadow, Light, DamageDetail, DamageDetail2,
            DamageDirtMud, DamageDetail3, DamageDecal, DamageBump, DamageNormal, 
            DamageSpec, DamageEnv, DamageShadow, DamageLight
mapTexel : *, R, G, B, A, RGB, AGB, Gray, RRR, GGG, BBB, AAA, RGBA, 1-R, 1-G, 
           1-B, 1-A
blendSrc, blendDest : Zero, One, SrcColor, InvSrcColor, SrcAlpha, InvSrcAlpha,
                      DestAlpha, InvDestAlpha, DestColor, InvDestColor,
                      SrcAlphaSat, BothSrcAlpha, BothInvSrcAlpha
opacity : 0.0 .. 1.0
angularLevel : -100 .. 100
mapAffectLevel : 0.0 .. 1.0
clip : On/Off or true/false (enables alpha test)
clipValue: 0..255 (alpha-test reference value)




    <basics class="rend::CShaderMaterial" 
            name="test_name"
            suffix=".fx"
            prefix="gta_"
            shader="system.diff"
            adapt="gta_default"
            container="/shared/"
            options="+DoubleSided+ZTest+ZWrite-CastShadows-ReceiveShadows"
            specular="on"
            specPower="15.2"
            emissive="200" />
One basics tag can be applied per configuration. All attributes are optional.

class  : material class name. Currently can be "rend::CShaderMaterial" only.
name   : material name to apply
suffix : material name tail to set
prefix : material name leading part to set
shader : shader system name to apply. If shader named 'diff.zsh' and located
         in System subfolder, it's name would be 'system.diff' then; 
adapt  : shader adaptation to set
container : material name tail to set
options : Combination of one or more +OptionToAdd-OptionToRemove. Option are:
          ZTest, ZWrite, DoubleSided, BackFace, RenderLast, CastShadows, 
          ReceiveShadows, ZCorrection
specular  : on/off or true/false (enables specular highlight)
specPower : 0.01 .. 1000.0 (specular power value. Default: 15.0)
emissive  : 0..255 (emissive color strength. Default 0)




    <color type="type" value="(0, 0, 5)" />

Zero or upto four color tags can be applied per configuration.

type : color type to set: ambient, diffuse, specular, emissive
value: RGB triplet with each component in range 0..255




    <sampler type="Bump" 
           forcetexture="flatnormals.dds"
           texture="genericbump.dds"
           forcetransition="damagemap.dds"
           transition="grass.dds"
           addressU="wrap"
           addressV="wrap"
           addressW="clamp"
           magFilter="linear"
           minFilter="point"
           mipFilter="linear"
           uv="Manual#1" 
           inputMap="Bump"
           inputTexel="RGB"
           inputAffectMap="Detail"
           inputAffectTexel="1-A"
           inputTransitionMap="DamageLevel"
           inputTransitionTexel="A"
           tileU="1.0"
           tileV="1.0"
           outputTexel="RGB"
           outputLevel="1.0"
           outputAngularLevel="40" />
Zero or more sampler tags can be applied per configuration. All attributes
except type are optional.

type : Type of sampler to apply setting to: Detail, Detail2, DirtMud, Detail3
       or Decal, Bump, Normal, Spec, Env, Shadow, Light.
forcetexture : forces texture filename to be applied. Will load and replace
               original map. Can not be applied with "texture" attribute.
texture      : default texture. Will be loaded and applied if no texture yet
               assigned. Can be empty (texture="") and it will remove
               currently assigned texture. Can not be applied with
               "forcetexture" attribute.
forcetransition: forces transition texture to be applied. Will load and replace
                 transition map. Can not be applied with "transition" attribute.
transition   : Transition texture. Will be loaded and applied if no transition
               texture yet assigned. Can be empty (transition="") and it will
               remove currently assigned transition texture. Can not be
               applied with "forcetransition" attribute.
addressU, addressV, addressW : addressing mode for U,V,W. Can be one of: 
               Wrap, Mirror, Clamp, Border, MirrorOnce.
magFilter, minFilter, mipFilter : magnify, minify and MipMap filter.
                                  Can be one of: None, Point, Linear, Aniso.
uv       : Type of source UV coordinates. Can be one of: Manual#1, Manual#2,
           Manual#3, Manual#4, AutoSphereEnv, WorldXZ.
inputMap : sampler source. It's usually matches it's type but not a must.
           For example, specular map sampler can take input from detail's
           texture alpha. Can be one of shader's available samplers.
inputTexel : sampler source texel if masking is needed. For example, Spec
             sampler can be configured as inputMap="Detail" inputTexel="A"
             to use diffuse alpha. Can be one of: R, G, B, A, RGB, AGB, 1-R,
             1-G, 1-B, 1-A, Gray, RGBA.
inputAffectMap : map that affects level of input. A sort of additional
                 masking. Can be any of shader's smaplers or "Const" to
                 disable masking.
inputAffectTexel: texel of map that affects level of input. Can be one of:
                  R, G, B, A, RGB, 1-R, 1-G, 1-B, 1-A.
inputTransitionMap : transition source. Beside shader-used maps, it can also
                     be "Const" (no transition), "VertColor" (to use vertex
                     color) or "DamageLevel" to use damage level as a source
                     for transition blend;
inputTransitionTexel : Texel of map to use (can be missing when use "Const"
                       or "DamageLevel" as transitionMap.
scale : uv mapping scale. 0.001 .. 10000.0
outputTexel : sampler output texel. By default, RGB.
outputLevel : 0.0 .. 1.0 (level of sampler)
outputAngularLevel: -100 .. 100 (angular affection of sampler).



    <custom name="Option Name" mode="add"
            value="1.0, 1.0, 0.25, 0.0" />

Zero or more custom shader values can be applied in configuration.

name : custom shader value name (see shader's CUSTOM.x section)
mode : optional. Can be either "remove" to remove custom value or "add" to
       add custom value. If missing, value is added.
value : a one, two, three or four component vector. Purpose and meaning is
        defined by shader.
       

    <user name="Option Name" mode="add" value="some value" />

Zero or more user-defined options can be applied in configuration.

name : user defined option name.
mode : optional. Can be either "remove" to remove user defined option or
       "add" to add user defined option. If missing, option is added.
value : any string containing the option value.
       

  </config>
</configset>
