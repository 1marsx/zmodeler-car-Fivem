/***************************************************************************
 *                          Zanoza Modeler v3.x                            *
 *      This is unpublished propietary source code of Zanoza Software.     *
 *      The copyright notice does not evidence any actual or intended      *
 *                    publication of such source code.                     *
 *                                                                         *
 *                 Copyright (c) 2002-2012 Zanoza Software.                *
 *                                                                         *
 *                        All rights reserved.                             *
 ***************************************************************************
 *--------------------------------------------------------------------------
 * @author:   Oleg M.
 *--------------------------------------------------------------------------
 * @purpose:  ZModeler 3.x Color + Bump + two Diffuse + Specular shader
 *--------------------------------------------------------------------------
 * @histroy: 29.08.2012. Created
<[[
UserName = "Bump+Dual Diffuse+Spec"
Description = "Color, Bump, two Diffise and Specular map"
Version  = 1.7
Options  = SOLID BUMP SPECULAR TRANSITION DUSTCOLOR DIRTCOLOR SCRATCHCOLOR BURNCOLOR DIFFUSECOLOR2 DIFFUSECOLOR3 DIFFUSECOLOR4
Samplers = BUMPMAP DETAIL DETAIL2 SPECMAP
ManualUV1 = v.vUV01.xy
ManualUV2 = v.vUV01.zw
ManualUV3 = v.vUV23.xy
ManualUV4 = v.vUV23.zw
EnvUV = vReflect.xy
WorldUV = v.vUVRefl.zw
AlphaRegister = 29

[BUMPMAP]
Variable = g_BumpMap
Register = 0
RegisterTrans = 1
Mask = RGB AGB GRB
Scale = 31.R
Level = 30.R
AngularLevel = 30.G

[DETAIL]
Variable = g_Diffuse
Register = 2
RegisterTrans = 3
Mask = R G B A RGB
Scale = 31.G
Level = 30.B
AngularLevel = 30.A

[DETAIL2]
Variable = g_Diffuse2
Register = 4
RegisterTrans = 5
Mask = R G B A RGB
Scale = 31.B
Level = 32.R
AngularLevel = 32.G

[SPECMAP]
Variable = g_SpecMap
Register = 6
RegisterTrans = 7
Mask = R G B A RGB
Scale = 31.A
Level = 32.B
AngularLevel = 32.A

[DUSTCOLOR]
Register    = 33

[DIRTCOLOR]
Register    = 34

[SCRATCHCOLOR]
Register    = 35

[BURNCOLOR]
Register    = 36

[DIFFUSECOLOR2]
Register    = 37

[DIFFUSECOLOR3]
Register    = 38

[DIFFUSECOLOR4]
Register    = 39

[ALPHABLEND]

[ALPHATEST]

[CUSTOM.1]
Name = MODE
Type = combo
Definition = DIFFUSE2_TOP_
Variants = Multiply = MULT, Add = ADD, Lerp = LERP, Mix = MIX
;Default = Add


]]>
*/

#pragma pack_matrix( row_major ) 

struct VS_INPUT
{
    float4 vPosition        : POSITION;
    float4 vNormal          : NORMAL;
    float4 vTangent         : TANGENT;
    float4 vColorDif        : COLOR0;
    float4 vUV01            : TEXCOORD0;
    float4 vUV23            : TEXCOORD1;
    float4 vDeformPosition  : TEXCOORD5;
    float4 vDeformNormal    : COLOR2;
    uint4  vBones           : BLENDINDICES;
    float4 vWeights         : BLENDWEIGHT;
};

struct VS_OUTPUT
{
    float4 vPosition  : POSITION;   //transformed position
    float4 vColor     : COLOR0;     //vertex color composition {ambient, diffuse, specular, 1}
    float4 vUV01      : TEXCOORD0;
    float4 vUV23      : TEXCOORD1;
    float4 vUVRefl    : TEXCOORD2;  //environment reflection;
    //precomputed stuff:
    float4 vNormal    : TEXCOORD4;  //world-space normal;
    float4 vViewer    : TEXCOORD5;  //camera-space position;
    float4 vBumpLit   : TEXCOORD6;  //tangent-space light;
    float4 vBumpViewer: TEXCOORD7;  //tangent-space position;
};

//----------------------------------------------------------------------
// globals:
//----------------------------------------------------------------------

#include "zmCommon.inl"

float4      g_alpha          : register(c29);  //[minlevel:testvalue, maxlevel, mapaffect, angular level]
float4      g_textureAmp     : register(c30);  //[bump level, bump angular level, diff level, diff angular level]
float4      g_textureScale   : register(c31);  //[bump uv scale, diff uv scale, diff2 scale, spec scale]
float4      g_diff2SpecAmp   : register(c32);  //[diff2 level, diff2 angular level, spec level, spec angular level]
float4      g_dustColor      : register(c33);  //dust color r,g,b and level in .a
float4      g_dirtColor      : register(c34);  //dirt color r,g,b and level in .a
float4      g_scratchColor   : register(c35);  //scratch color r,g,b and level in .a
float4      g_burnColor      : register(c36);  //burn color r,g,b and level in .a
                                               //level of main diffuse is in g_colors[1].a;
float4      g_diffuse2Color  : register(c37);  //diffuse2 color r,g,b and level in .a
float4      g_diffuse3Color  : register(c38);  //diffuse3 color r,g,b and level in .a
float4      g_diffuse4Color  : register(c39);  //diffuse4 color r,g,b and level in .a

// textures:
sampler     g_BumpMap        : register(s[0]);
sampler     g_BumpMapTrans   : register(s[1]);
sampler     g_Diffuse        : register(s[2]);
sampler     g_DiffuseTrans   : register(s[3]);
sampler     g_Diffuse2       : register(s[4]);
sampler     g_Diffuse2Trans  : register(s[5]);
sampler     g_SpecMap        : register(s[6]);
sampler     g_SpecMapTrans   : register(s[7]);


#ifdef VERTEX_SHADER
VS_OUTPUT mainVS(in VS_INPUT v)
{
    VS_OUTPUT output = (VS_OUTPUT)0;
    output.vNormal = v.vNormal;
    float4 vTangent = v.vTangent;
    output.vPosition = transformInput(v, output.vNormal, vTangent, output.vViewer);
    output.vColor = any(v.vColorDif.rgb) ? v.vColorDif : 1;

    output.vUV01 = v.vUV01;
    output.vUV23 = v.vUV23;
    //bump-map reflection can mix this spehere-env uv mapping with bump-reflected env;
    output.vUVRefl.xy = (mul(output.vNormal.xyz, (float3x3)g_mView).xy+1)/2;
    output.vUVRefl.zw = v.vPosition.xz;

    // bump-transformed light:
    //-----
    float3x3 worldToTangentSpace;
    worldToTangentSpace[0] = vTangent.xyz;
    worldToTangentSpace[1] = normalize(cross(vTangent.xyz, output.vNormal.xyz)*(-v.vTangent.w));
    worldToTangentSpace[2] = output.vNormal.xyz;
    output.vBumpLit = normalize(float4(mul(worldToTangentSpace, -g_lightDir.xyz), 1));
    output.vBumpViewer = float4(mul(worldToTangentSpace, output.vViewer.xyz), 1);

    return output;
}
#endif //VERTEX_SHADER

#ifdef PIXEL_SHADER
//------------------------------------------------------------
//  PixelShader: generic Dif+Bump+SpecMap+Refl;
//------------------------------------------------------------
float4 mainPS(in VS_OUTPUT v) : COLOR0
{
    float4 oColor;
    float4 CONST_TEXEL   = float4(1,1,1,1);
    float2 vReflect      = v.vUVRefl.xy;
    float4 BUMPMAP_TEXEL = tex2D(BUMPMAP_SOURCE, BUMPMAP_UV_SOURCE/g_textureScale.x);
    float4 DETAIL_TEXEL  = tex2D(DETAIL_SOURCE,  DETAIL_UV_SOURCE/g_textureScale.y);
    float4 DETAIL2_TEXEL = tex2D(DETAIL2_SOURCE, DETAIL2_UV_SOURCE/g_textureScale.z);
    float4 SPECMAP_TEXEL = tex2D(SPECMAP_SOURCE, SPECMAP_UV_SOURCE/g_textureScale.w);
    float4 VCOLOR_TEXEL  = v.vColor;
    DETAIL_TEXEL  = lerp(DETAIL_TEXEL,  tex2D(g_DiffuseTrans,  DETAIL_UV_SOURCE/g_textureScale.y), DETAIL_TRANSITION);
    DETAIL2_TEXEL = lerp(DETAIL2_TEXEL, tex2D(g_Diffuse2Trans, DETAIL2_UV_SOURCE/g_textureScale.z),DETAIL2_TRANSITION);
    SPECMAP_TEXEL = lerp(SPECMAP_TEXEL, tex2D(g_SpecMapTrans, SPECMAP_UV_SOURCE/g_textureScale.w), SPECMAP_TRANSITION);
    BUMPMAP_TEXEL = lerp(BUMPMAP_TEXEL, tex2D(g_BumpMapTrans, BUMPMAP_UV_SOURCE/g_textureScale.x), BUMPMAP_TRANSITION);

    float3 normal = normalize(v.vNormal.xyz);
    float3 bumpNormal = normalize((2*(BUMPMAP_INPUT*BUMPMAP_INPUT_MASK)BUMPMAP_MASK)-1);
    float3 bumpLight = normalize(v.vBumpLit.xyz);
    
    //
    // regular vs bump-mapped normals and light:
    // float4 LightTemp is [non-bump diff, non-bump spec, bump-diff, bump spec]
    float4 specData = 0;
#ifdef SPECULAR_ENABLED
    specData.xy = float2(dot(-g_lightDir.xyz, normal), dot(normal, normalize(v.vViewer.xyz-g_lightDir.xyz)));
    specData.zw = float2(dot(bumpLight, bumpNormal), dot(bumpNormal, normalize(bumpLight+v.vBumpViewer.xyz)));
    float4 LightTemp = float4(
                    saturate(specData.x), 
                    lit(specData.x, specData.y, g_colors[2].a).z,
                    saturate(specData.z),
                    lit(specData.z, specData.w, g_colors[2].a).z); 
    
#else
    float4 LightTemp = float4(
                    saturate(dot(-g_lightDir.xyz, normal)), 
                    0,
                    saturate(dot(bumpLight, bumpNormal)),
                    0); 
#endif //SPECULAR_ENABLED
    // alter diffuse light factor by ambient illumitaion addon:
    LightTemp.x = saturate(LightTemp.x + (g_ambientLight.r + g_ambientLight.g + g_ambientLight.b)/3);
    LightTemp.z = saturate(LightTemp.z + (g_ambientLight.r + g_ambientLight.g + g_ambientLight.b)/3);


    //
    //angular level (.z - final (after angular level), .w - initial)
    float4 Temp   = float4(1,1,1,
                           lerp(saturate(dot(v.vViewer.xyz, normal)), saturate(dot(v.vBumpViewer, bumpNormal)), g_textureAmp.x));
    
    if (g_textureAmp.y >= 0)
      Temp.z = lerp(1, Temp.w, g_textureAmp.y)*g_textureAmp.x;
    else
      Temp.z = lerp(1, 1-Temp.w, abs(g_textureAmp.y))*g_textureAmp.x;

    float3 fDiffuse1Color   = (DETAIL_INPUT)DETAIL_MASK;
    float3 fDiffuse2Color   = (DETAIL2_INPUT)DETAIL2_MASK;
    float3 fSpecMapColor    = (SPECMAP_INPUT)SPECMAP_MASK;

    if (g_textureAmp.w >= 0)
      Temp.x = lerp(1, Temp.z, g_textureAmp.w)*g_textureAmp.z*(DETAIL_INPUT_MASK);
    else
      Temp.x = lerp(1, 1-Temp.z, abs(g_textureAmp.w))*g_textureAmp.z*(DETAIL_INPUT_MASK);
    if (g_diff2SpecAmp.y >= 0)
      Temp.y = lerp(1, Temp.z, g_diff2SpecAmp.y)*g_diff2SpecAmp.x*(DETAIL2_INPUT_MASK);
    else
      Temp.y = lerp(1, 1-Temp.z, abs(g_diff2SpecAmp.y))*g_diff2SpecAmp.x*(DETAIL2_INPUT_MASK);

    float3 fDetailColor = 
#if defined(DIFFUSE2_TOP_MULT)
      lerp(1, fDiffuse1Color, Temp.x)*lerp(1, fDiffuse2Color, Temp.y);
#elif defined(DIFFUSE2_TOP_MIX)
      lerp(1, fDiffuse1Color*Temp.x + fDiffuse2Color*Temp.y, saturate(Temp.x+Temp.y));
#elif defined(DIFFUSE2_TOP_LERP)
      lerp(lerp(1, fDiffuse1Color, Temp.x), fDiffuse2Color, Temp.y);
#else
      lerp(1, fDiffuse1Color, Temp.x) + fDiffuse2Color*Temp.y;
#endif


    //
    // environment UV computation are wrong in tangent space (vBumpReflect); 
    // however it's suitable at the moment, since I reduce affection (Temp.z)
    // when bump-map normal pointing around (0,0,1)
    //
    float2 vBumpReflect   = (reflect(bumpNormal, v.vBumpViewer.xyz).xy + 1)/2;
    vReflect              = lerp(vReflect, vBumpReflect, Temp.z*(1-saturate(bumpNormal.z)));
   
    // diffuse level (with respect to bump level/angular)
    Temp.x = lerp(LightTemp.x, LightTemp.z, Temp.z); 

    //
    // angular level on spec:
    if (g_diff2SpecAmp.w >= 0)
      Temp.z = lerp(1, Temp.w, g_diff2SpecAmp.w)*g_diff2SpecAmp.z;
    else
      Temp.z = lerp(1, 1-Temp.w, abs(g_diff2SpecAmp.w))*g_diff2SpecAmp.z;

    // specular level (with respect to bump level/angular)
    Temp.y = lerp(LightTemp.y, LightTemp.w, Temp.z); 

    //
    // advanced diffuse color, and shine/opacity overload controllers:
    ADVANCED_COLOR_DIFFUSELEVEL(fAdvColorLevels)
    ADVANCED_COLOR_DIFFUSEVAR(fAdvancedDiffuseColor, fAdvColorLevels)
    ADVANCED_COLOR_EFFECTLEVELS(fEffectLevels)
    ADVANCED_COLOR_EFFECTVAR(fEffectColor, fEffectLevels)
    ADVANCED_COLOR_OPTIONS(advShineOpac, fEffectLevels, fAdvColorLevels)
    
    //regular:
    oColor.rgb =
                // ambient: 
                (g_colors[0].rgb + 0.2*v.vColor.rgb + 0.8*fDetailColor*g_ambientLight.rgb)*g_ambientLight.rgb +
                // diffuse component:
                (fAdvancedDiffuseColor*v.vColor.rgb*fDetailColor*(1-fEffectColor.a) + fEffectColor.rgb*fEffectColor.a)*max(g_colors[3].a, Temp.x) +
                // matted:
                advShineOpac.r*(
                  // specular component:
                  g_colors[2].rgb*(fSpecMapColor*(SPECMAP_INPUT_MASK)*Temp.w)*(Temp.y + Temp.y*(1+Temp.x)*saturate(advShineOpac.g)) +
                  // emissive component:
                  g_colors[3].rgb*g_colors[3].a
                );
                

#ifdef ALPHABLEND_ENABLED
    if (g_alpha.w >= 0)
      Temp.x = lerp(1, Temp.w, g_alpha.w);
    else
      Temp.x = lerp(1, 1-Temp.w, abs(g_alpha.w));
    oColor.a = saturate(lerp(1, ALPHABLEND_INPUT, g_alpha.z)*ALPHABLEND_VERTEXCOLOR*Temp.x*g_alpha.y + advShineOpac.b);
#else
    oColor.a = g_alpha.y;
#endif//ALPHABLEND_ENABLED
#ifdef ALPHATEST_ENABLED
    clip(oColor.a - g_alpha.x);
#endif//ALPHATEST_ENABLED

    return oColor;
}
#endif //PIXEL_SHADER

