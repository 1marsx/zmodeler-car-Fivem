/***************************************************************************
 *                          Zanoza Modeler v3.x                            *
 *      This is unpublished propietary source code of Zanoza Software.     *
 *      The copyright notice does not evidence any actual or intended      *
 *                    publication of such source code.                     *
 *                                                                         *
 *                 Copyright (c) 2002-2012 Zanoza Software.                *
 *                                                                         *
 *                        All rights reserved.                             *
 ***************************************************************************
 *--------------------------------------------------------------------------
 * @author:   Oleg M.
 *--------------------------------------------------------------------------
 * @purpose:  ZModeler 3.x Color + Triple Diffuse Texture + Specular + Environment
 *--------------------------------------------------------------------------
 * @histroy: 28.08.2012. Created
<[[
UserName = "Triple Diffuse+Spec+Env"
Description = "Color, Triple Diffuse, Specular and Environment map"
Version  = 1.6
Options  = SOLID SPECULAR ENVIRONMENT FRESNEL TRANSITION DUSTCOLOR DIRTCOLOR SCRATCHCOLOR BURNCOLOR DIFFUSECOLOR2 DIFFUSECOLOR3 DIFFUSECOLOR4
Samplers = DETAIL DETAIL2 DETAIL3 SPECMAP ENVMAP
ManualUV1 = v.vUV01.xy
ManualUV2 = v.vUV01.zw
ManualUV3 = v.vUV23.xy
ManualUV4 = v.vUV23.zw
EnvUV = v.vUVRefl.xy
WorldUV = v.vUVRefl.zw
AlphaRegister = 29

[DETAIL]
Variable = g_Diffuse1
Register = 0
RegisterTrans = 1
Mask = R G B A RGB
Scale = 32.R
Level = 30.R
AngularLevel = 30.G

[DETAIL2]
Variable = g_Diffuse2
Register = 2
RegisterTrans = 3
Mask = R G B A RGB
Scale = 32.A
Level = 33.R
AngularLevel = 33.G

[DETAIL3]
Variable = g_Diffuse3
Register = 4
RegisterTrans = 5
Mask = R G B A RGB
Scale = 34.R
Level = 34.G
AngularLevel = 34.B

[SPECMAP]
Variable = g_SpecMap
Register = 7
RegisterTrans = 8
Mask = R G B A RGB
Scale = 32.G
Level = 30.B
AngularLevel = 30.A
	
[ENVMAP]
Variable = g_EnvMap
Register = 8
Mask = RGB
Scale = 32.B
Level = 31.R
AngularLevel = 31.B
	
[DUSTCOLOR]
Register    = 35

[DIRTCOLOR]
Register    = 36

[SCRATCHCOLOR]
Register    = 37

[BURNCOLOR]
Register    = 38

[DIFFUSECOLOR2]
Register    = 39

[DIFFUSECOLOR3]
Register    = 40

[DIFFUSECOLOR4]
Register    = 41

[ALPHABLEND]

[ALPHATEST]

[CUSTOM.1]
Name = Opacity Amplifier
Slot = 31.G
Type = float
Min = 0.0
Max = 1.0
Default = 0.0

[CUSTOM.2]
Name = Fresnel
Slot = 31.A
Type = float
Min = 0.001
Max = 0.3
Default = 0.018

[CUSTOM.3]
Name = MODE
Type = combo
Definition = DIFFUSE2_TOP_
Variants = Multiply = MULT, Add = ADD, Lerp = LERP, Mix = MIX

[CUSTOM.4]
Name = MODE2
Type = combo
Definition = DIFFUSE3_TOP_
Variants = Multiply = MULT, Add = ADD, Lerp = LERP

]]>
*/

#pragma pack_matrix( row_major ) 

struct VS_INPUT
{
    float4 vPosition        : POSITION;
    float4 vNormal          : NORMAL;
    float4 vColorDif        : COLOR0;
    float4 vUV01            : TEXCOORD0;
    float4 vUV23            : TEXCOORD1;
    float4 vDeformPosition  : TEXCOORD5;
    float4 vDeformNormal    : COLOR2;
    uint4  vBones           : BLENDINDICES;
    float4 vWeights         : BLENDWEIGHT;
};

struct VS_OUTPUT
{
    float4 vPosition  : POSITION;   //transformed position
    float4 vColorDif  : COLOR0;
    //precomputed stuff:
    float4 vNormal    : TEXCOORD0;  //world-space normal;
    float4 vViewer    : TEXCOORD1;  //camera-space position;
    float4 vUV01      : TEXCOORD2;
    float4 vUV23      : TEXCOORD3;
    float4 vUVRefl    : TEXCOORD4;
};

//----------------------------------------------------------------------
// globals:
//----------------------------------------------------------------------

#include "zmCommon.inl"

float4      g_alpha          : register(c29);  //[minlevel:testvalue, maxlevel, mapaffect, angular level]
float4      g_textureAmp     : register(c30);  //[diff amp, diff angular, spec amp, spec angular]
float4      g_environment    : register(c31);  //[level, refl opacity amp, angular level, fresnel value]
float4      g_textureScale   : register(c32);  //[diff scale, spec scale, refl scale, diff2 scale]
float4      g_textureAmp2    : register(c33);  //[diff2 amp, diff2 angular, 0, 0]
float4      g_textureAmp3    : register(c34);  //[diff3 scale, diff3 amp, diff3 angular, 0]
float4      g_dustColor      : register(c35);  //dust color r,g,b and level in .a
float4      g_dirtColor      : register(c36);  //dirt color r,g,b and level in .a
float4      g_scratchColor   : register(c37);  //scratch color r,g,b and level in .a
float4      g_burnColor      : register(c38);  //burn color r,g,b and level in .a
                                               //level of main diffuse is in g_colors[1].a;
float4      g_diffuse2Color  : register(c39);  //diffuse2 color r,g,b and level in .a
float4      g_diffuse3Color  : register(c40);  //diffuse3 color r,g,b and level in .a
float4      g_diffuse4Color  : register(c41);  //diffuse4 color r,g,b and level in .a

// textures:
sampler     g_Diffuse1       : register(s[0]);
sampler     g_Diffuse1Trans  : register(s[1]);
sampler     g_Diffuse2       : register(s[2]);
sampler     g_Diffuse2Trans  : register(s[3]);
sampler     g_Diffuse3       : register(s[4]);
sampler     g_Diffuse3Trans  : register(s[5]);
sampler     g_EnvMap         : register(s[6]);
sampler     g_SpecMap        : register(s[7]);
sampler     g_SpecMapTrans   : register(s[8]);

#ifdef VERTEX_SHADER
VS_OUTPUT mainVS(in VS_INPUT v)
{
    VS_OUTPUT output = (VS_OUTPUT)0;
    output.vNormal = v.vNormal;
    float4 vTangent = (float4)0;
    output.vPosition = transformInput(v, output.vNormal, vTangent, output.vViewer);
    output.vColorDif = any(v.vColorDif.rgb) ? v.vColorDif : 1;

    output.vUV01 = v.vUV01;
    output.vUV23 = v.vUV23;
    output.vUVRefl.xy = (mul(output.vNormal.xyz, (float3x3)g_mView).xy+1)/2;
    output.vUVRefl.zw = v.vPosition.xz;

    return output;
}
#endif //VERTEX_SHADER

#ifdef PIXEL_SHADER
//------------------------------------------------------------
//  PixelShader: generic Color+Dif+Refl;
//------------------------------------------------------------
float4 mainPS(in VS_OUTPUT v) : COLOR0
{
    float4 oColor;
    float4 CONST_TEXEL   = float4(1,1,1,1);
    float4 VCOLOR_TEXEL  = v.vColorDif;
    float4 DETAIL_TEXEL  = tex2D(DETAIL_SOURCE, DETAIL_UV_SOURCE/g_textureScale.x);
    float4 DETAIL2_TEXEL = tex2D(DETAIL2_SOURCE, DETAIL2_UV_SOURCE/g_textureScale.w);
    float4 DETAIL3_TEXEL = tex2D(DETAIL3_SOURCE, DETAIL3_UV_SOURCE/g_textureAmp3.x);
    float4 SPECMAP_TEXEL = tex2D(SPECMAP_SOURCE, SPECMAP_UV_SOURCE/g_textureScale.y);
    float4 ENVMAP_TEXEL  = tex2D(ENVMAP_SOURCE, ENVMAP_UV_SOURCE/g_textureScale.z);
    DETAIL_TEXEL = lerp(DETAIL_TEXEL, tex2D(g_Diffuse1Trans, DETAIL_UV_SOURCE/g_textureScale.x), DETAIL_TRANSITION);
    DETAIL2_TEXEL = lerp(DETAIL2_TEXEL, tex2D(g_Diffuse2Trans, DETAIL2_UV_SOURCE/g_textureScale.w), DETAIL2_TRANSITION);
    DETAIL3_TEXEL = lerp(DETAIL3_TEXEL, tex2D(g_Diffuse3Trans, DETAIL3_UV_SOURCE/g_textureAmp3.x), DETAIL3_TRANSITION);
    SPECMAP_TEXEL = lerp(SPECMAP_TEXEL, tex2D(g_SpecMapTrans, SPECMAP_UV_SOURCE/g_textureScale.y), SPECMAP_TRANSITION);

    float3 light = -g_lightDir.xyz;
    float4 Temp   = float4(1,1,0,saturate(dot(v.vViewer.xyz, v.vNormal.xyz))); 
    
#ifdef SPECULAR_ENABLED
    float3 normal = normalize(v.vNormal.xyz);
    float3 halfSpec = normalize(light + v.vViewer.xyz);
    Temp.xy = float2(dot(normal, light), dot(normal, halfSpec));
    float4 LitCoef = lit(Temp.x, Temp.y, g_colors[2].a);
#else
    float4 LitCoef = float4(1, saturate(dot(light, v.vNormal.xyz)), 0, 0);
#endif //SPECULAR_ENABLED
    // alter diffuse light factor by ambient illumitaion addon:
    LitCoef.y = saturate(LitCoef.y + (g_ambientLight.r + g_ambientLight.g + g_ambientLight.b)/3);

    float3 fDiffuse1Color   = (DETAIL_INPUT)DETAIL_MASK;
    float3 fDiffuse2Color   = (DETAIL2_INPUT)DETAIL2_MASK;
    float3 fDiffuse3Color   = (DETAIL3_INPUT)DETAIL3_MASK;
    float3 fSpecMapColor    = (SPECMAP_INPUT)SPECMAP_MASK;
    float3 fEnvironColor    = (ENVMAP_INPUT*(ENVMAP_INPUT_MASK))ENVMAP_MASK;
    //
    // diff angular value
    if (g_textureAmp.y >= 0)
      Temp.x = lerp(1, Temp.w, g_textureAmp.y)*g_textureAmp.x*(DETAIL_INPUT_MASK);
    else
      Temp.x = lerp(1, 1-Temp.w, abs(g_textureAmp.y))*g_textureAmp.x*(DETAIL_INPUT_MASK);
    //
    // specmap angular value
    if (g_textureAmp.w >= 0)
      Temp.y = lerp(1, Temp.w, g_textureAmp.w)*g_textureAmp.z;
    else
      Temp.y = lerp(1, 1-Temp.w, abs(g_textureAmp.w))*g_textureAmp.z;
    //
    // refl angular value
    if (g_environment.z >= 0)
      Temp.z = lerp(1, Temp.w, g_environment.z)*g_environment.x;
    else
      Temp.z = lerp(1, 1-Temp.w, abs(g_environment.z))*g_environment.x;

    float fresnel = (1-LitCoef.y);
    LitCoef.w = fresnel*fresnel;
    LitCoef.w = LitCoef.w*LitCoef.w;
    LitCoef.w = saturate(mad(LitCoef.w*fresnel, 1-saturate(g_environment.w), g_environment.w));
    fEnvironColor = fEnvironColor*saturate(Temp.z+(0.7 + g_environment.x)*LitCoef.w);
    
    //
    // diff2 angular value:
    if (g_textureAmp2.y >= 0)
      Temp.z = lerp(1, Temp.w, g_textureAmp2.y)*g_textureAmp2.x*(DETAIL2_INPUT_MASK);
    else
      Temp.z = lerp(1, 1-Temp.w, abs(g_textureAmp2.y))*g_textureAmp2.x*(DETAIL2_INPUT_MASK);

    float3 fDetailColor = 
#if defined(DIFFUSE2_TOP_MULT)
      lerp(1, fDiffuse1Color, Temp.x)*lerp(1, fDiffuse2Color, Temp.z);
#elif defined(DIFFUSE2_TOP_MIX)
      lerp(1, fDiffuse1Color*Temp.x + fDiffuse2Color*Temp.z, saturate(Temp.x+Temp.z));
#elif defined(DIFFUSE2_TOP_LERP)
      lerp(lerp(1, fDiffuse1Color, Temp.x), fDiffuse2Color, Temp.z);
#else
      lerp(1, fDiffuse1Color, Temp.x) + fDiffuse2Color*Temp.z;
#endif

    
    // diff3 angular value:
    if (g_textureAmp3.z >= 0)
      Temp.z = lerp(1, Temp.w, g_textureAmp3.z)*g_textureAmp3.y*(DETAIL3_INPUT_MASK);
    else
      Temp.z = lerp(1, 1-Temp.w, abs(g_textureAmp3.z))*g_textureAmp3.y*(DETAIL3_INPUT_MASK);

    fDetailColor = 
#if defined(DIFFUSE3_TOP_MULT)
      fDetailColor*lerp(1, fDiffuse3Color, Temp.z);
#elif defined(DIFFUSE2_TOP_LERP)
      lerp(fDetailColor, fDiffuse3Color, Temp.z);
#else
      fDetailColor + fDiffuse3Color*Temp.z;
#endif

    //
    // advanced diffuse color, and shine/opacity overload controllers:
    ADVANCED_COLOR_DIFFUSELEVEL(fAdvColorLevels)
    ADVANCED_COLOR_DIFFUSEVAR(fAdvancedDiffuseColor, fAdvColorLevels)
    ADVANCED_COLOR_EFFECTLEVELS(fEffectLevels)
    ADVANCED_COLOR_EFFECTVAR(fEffectColor, fEffectLevels)
    ADVANCED_COLOR_OPTIONS(advShineOpac, fEffectLevels, fAdvColorLevels)

    oColor.rgb =
                // ambient: 
                (g_colors[0].rgb + 0.2*v.vColorDif.rgb + 0.8*fDetailColor*g_ambientLight.rgb)*g_ambientLight.rgb +
                // diffuse component:
                (fAdvancedDiffuseColor*v.vColorDif.rgb*fDetailColor*(1-fEffectColor.a) + fEffectColor.rgb*fEffectColor.a)*max(g_colors[3].a, LitCoef.y) +
                // matted:
                advShineOpac.r*(
                  // specular component:
                  g_colors[2].rgb*(fSpecMapColor*(SPECMAP_INPUT_MASK)*Temp.y)*(LitCoef.z + LitCoef.z*(1+LitCoef.y)*saturate(advShineOpac.g)) +
                  // reflection component:
                  fEnvironColor +
                  // emissive component:
                  g_colors[3].rgb*g_colors[3].a
                );

#ifdef ALPHABLEND_ENABLED
    if (g_alpha.w >= 0)
      Temp.x = lerp(1, Temp.w, g_alpha.w);
    else
      Temp.x = lerp(1, 1-Temp.w, abs(g_alpha.w));
    oColor.a = saturate(lerp(1, ALPHABLEND_INPUT, g_alpha.z)*ALPHABLEND_VERTEXCOLOR*Temp.x*g_alpha.y + 
                        length(fEnvironColor)*g_environment.y + advShineOpac.b);
#else
    oColor.a = g_alpha.y;
#endif//ALPHABLEND_ENABLED
#ifdef ALPHATEST_ENABLED
    clip(oColor.a - g_alpha.x);
#endif//ALPHATEST_ENABLED
    return oColor;
}
#endif //PIXEL_SHADER

